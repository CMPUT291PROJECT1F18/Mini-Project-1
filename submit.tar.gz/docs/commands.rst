Command Line Use
================

.. argparse::
   :module: mini_project_1.__main__
   :func: get_parser
   :prog: mini_project_1
