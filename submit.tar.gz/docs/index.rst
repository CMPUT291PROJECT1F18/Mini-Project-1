Welcome to mini-project-1's documentation!
==========================================

This code is open source, and is `available on GitHub`_.

.. _available on GitHub: https://github.com/CMPUT291PROJECT1F18/Mini-Project-1

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Overview<readme>
   Shell Startup Command Line Usage<commands>
   Mini-Project-1 Shell Command Line Usage <shellcommands>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
