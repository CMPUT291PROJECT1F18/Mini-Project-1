miniProject Members:
    * nklapste - Nathan Klapstein
    * rfurrer - Ryan Furrer
    * tlorincz- Thomas Lorincz

Collaborators:
    * Our group did not collaborate with anyone else

Information Sources:
    * Class notes
